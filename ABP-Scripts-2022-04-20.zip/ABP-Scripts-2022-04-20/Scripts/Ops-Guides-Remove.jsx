#target illustrator

var myDoc = app.activeDocument;

if(myDoc.guides.length > "0"){

    myDoc.guides.removeALL();

}
