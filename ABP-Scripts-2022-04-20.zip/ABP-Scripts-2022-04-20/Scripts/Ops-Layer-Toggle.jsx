#target illustrator

var doc = activeDocument;
var layer = doc.activeLayer;
    layer.visible = ! layer.visible
