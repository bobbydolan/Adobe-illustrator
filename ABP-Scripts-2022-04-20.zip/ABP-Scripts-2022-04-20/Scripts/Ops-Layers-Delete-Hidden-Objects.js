/*
    <javascriptresource>
    <name>[Ops] Unlock All</name>
    <enableinfo>true</enableinfo>
    <category>Ops</category>
    </javascriptresource>
*/
app.executeMenuCommand('showAll');
app.executeMenuCommand('Remove Anchor Points menu');

