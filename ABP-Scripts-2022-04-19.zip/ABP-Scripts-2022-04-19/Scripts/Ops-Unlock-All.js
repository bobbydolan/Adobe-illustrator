/*
    <javascriptresource>
    <name>[Ops] Unlock All</name>
    <enableinfo>true</enableinfo>
    <category>Ops</category>
    </javascriptresource>
*/
app.executeMenuCommand('unlockAll');