// // turn edited flag off
activeDocument.saved = true;
app.executeMenuCommand('close');
