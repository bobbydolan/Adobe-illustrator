// // This script shows all
app.executeMenuCommand("showAll");
