// // This script hides all selections
app.executeMenuCommand("hide");